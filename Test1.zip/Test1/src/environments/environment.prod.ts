export const environment = {
  production: true, 
  apiUrl: 'https://servicesbeta.cassport.com/CassPortAPIGateway',
  webuiApiUrl: 'https://mybeta.cassport.com/CassPortWeb',
  loginURL: 'https://mybeta.cassport.com/CassPortWeb/identity/login',
  SignoutUrl: 'https://mybeta.cassport.com/CassAuth/identity/logout',
  envUrl : 'https://mybeta.cassport.com',
  tableauEnv: 'https://tableauservertest.cassinfo.com'  
};
