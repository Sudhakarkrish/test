export const environment = {
  production: false,
  development: true,
  apiUrl: 'https://servicesdev.cassport.com/CassPortAPIGateway',
  webuiApiUrl: 'https://mynew.dev.cassport.com/CassPort',
  loginURL: 'https://mynew.dev.cassport.com/CassPort/identity/login',
  SignoutUrl: 'https://mynew.dev.cassport.com/CassAuth/identity/logout',
  envUrl: 'https://mynew.dev.cassport.com',
  tableauEnv: 'https://tableauservertest.cassinfo.com'

};
