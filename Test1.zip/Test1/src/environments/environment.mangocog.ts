export const environment = {
    production: false,
    development: false,
    beta: false,
    mangocog: true, 
    apiUrl: 'https://servicesdevcog.cassport.com/CassPortAPIGateway',
    webuiApiUrl: 'https://mynew.devcog.cassport.com/CassPort',
    loginURL: 'https://mynew.devcog.cassport.com/CassPort/identity/login',
    SignoutUrl: 'https://mynew.devcog.cassport.com/CassAuth/identity/logout',
    envUrl : 'https://mynew.devcog.cassport.com',
    tableauEnv: 'https://tableauservertest.cassinfo.com'
     
  };