import { Component, OnInit } from '@angular/core';
import { SpinnerService } from 'src/app/_services/spinner.service';

@Component({
  selector: 'app-customspinner',
  templateUrl: './customspinner.component.html',
  styleUrls: ['./customspinner.component.css']
})
export class CustomspinnerComponent implements OnInit {
  showCustomLoader:boolean = false;
  constructor(private spinnerService:SpinnerService) { }

  ngOnInit() {
    this.spinnerService.getEmittedValue().subscribe(item=>{
      this.showCustomLoader=item;
    });
  }

}
