import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomspinnerComponent } from './customspinner.component';

describe('CustomspinnerComponent', () => {
  let component: CustomspinnerComponent;
  let fixture: ComponentFixture<CustomspinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomspinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomspinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
