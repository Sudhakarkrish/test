import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CommonListboxComponent } from './common-listbox/common-listbox.component';
import { SpinnerComponent } from './spinner/spinner.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatepickerComponent } from './datepicker/datepicker.component';
import { ErrorComponent } from './error/error.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AlertComponent } from '../_directives';
import { SharedRoutingModule } from './shared-routing.module';
import { ArrayFilterPipe,ArraySortPipe} from '../_directives/array.pipe';
import { PasswordStrengthBarComponent } from '../_directives/passwordstrength';
import { ToastComponent } from '../_directives/toast/toast.component';
import { SortTable } from '../_directives/sortable';
import { WarningComponent } from './warning/warning.component';
import { WarningmessageComponent } from './warningmessage/warningmessage.component';
import { WarningdeletemessageComponent } from './warningdeletemessage/warningdeletemessage.component';
import { CustomspinnerComponent } from './customspinner/customspinner.component';

@NgModule({
  declarations: [
    CommonListboxComponent,
    DatepickerComponent,        
    SpinnerComponent,
    ErrorComponent,
    AlertComponent,
    ArrayFilterPipe,
    ArraySortPipe,
    PasswordStrengthBarComponent,
    ToastComponent,
    SortTable,
    WarningComponent,
    WarningmessageComponent,
    WarningdeletemessageComponent,
    CustomspinnerComponent
  ],
  entryComponents: [ErrorComponent,WarningComponent,WarningmessageComponent,WarningdeletemessageComponent],
  imports: [
    CommonModule,
    SharedRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule
  ],
  exports: [
    CommonListboxComponent,
    DatepickerComponent,        
    SpinnerComponent,
    ErrorComponent,
    AlertComponent,
    ArrayFilterPipe,
    ArraySortPipe,
    PasswordStrengthBarComponent,
    ToastComponent,
    SortTable,
    WarningComponent,
    WarningmessageComponent,
    WarningdeletemessageComponent,
    CustomspinnerComponent
  ]
})
export class SharedModule { }
