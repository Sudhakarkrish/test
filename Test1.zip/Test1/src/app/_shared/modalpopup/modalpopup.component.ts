import { Component, OnInit, Input } from '@angular/core';
import{ NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { Shipper } from 'src/app/_models/shipper';

@Component({
  selector: 'app-modalpopup',
  templateUrl: './modalpopup.component.html',
  styleUrls: ['./modalpopup.component.css']
})
export class ModalpopupComponent implements OnInit {
  dataShipperModal: Shipper[];  
  @Input() dataShipperModalPermission: any;

  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.dataShipperModal = this.dataShipperModalPermission;
  }
}
