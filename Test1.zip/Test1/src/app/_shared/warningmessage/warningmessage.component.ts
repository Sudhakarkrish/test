import { Component, OnInit, Input } from '@angular/core';
import {Router} from '@angular/router'
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-warningmessage',
  templateUrl: './warningmessage.component.html',
  styleUrls: ['./warningmessage.component.css']
})
export class WarningmessageComponent implements OnInit {
 @Input() typeName:any;
  constructor(public activeModal: NgbActiveModal, public router:Router) { }

  ngOnInit() {
  }

  Redirect(){
    this.router.navigate(['']);
    this.activeModal.close();
  }

  Close(){
    this.activeModal.close('save');
  }

}
