import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WarningdeletemessageComponent } from './warningdeletemessage.component';

describe('WarningdeletemessageComponent', () => {
  let component: WarningdeletemessageComponent;
  let fixture: ComponentFixture<WarningdeletemessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WarningdeletemessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WarningdeletemessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
