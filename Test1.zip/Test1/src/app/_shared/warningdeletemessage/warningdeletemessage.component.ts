import { Component, OnInit , Input} from '@angular/core';
import {Router} from '@angular/router'
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-warningdeletemessage',
  templateUrl: './warningdeletemessage.component.html',
  styleUrls: ['./warningdeletemessage.component.css']
})
export class WarningdeletemessageComponent implements OnInit {
  @Input() typeName:any;
  @Input() headerName:any;
  actionName:any;
  constructor(public activeModal: NgbActiveModal, public router:Router) { }

  ngOnInit() {
    this.actionName = this.headerName.toLowerCase();
  }

  Cancel(){
    this.activeModal.close();
  }

  Delete(){
    this.activeModal.close('Delete');
  }
}
