import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonListboxComponent } from './common-listbox.component';

describe('CommonListboxComponent', () => {
  let component: CommonListboxComponent;
  let fixture: ComponentFixture<CommonListboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonListboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonListboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
