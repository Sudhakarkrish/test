import { Component, Input, Output, EventEmitter, OnInit, forwardRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { HelperService } from 'src/app/_services';
declare var require: any;
const intersectionwith = require('lodash.intersectionwith');
const differenceWith = require('lodash.differencewith');

@Component({
  selector: 'app-common-listbox',
  templateUrl: './common-listbox.component.html',
  styleUrls: ['./common-listbox.component.css'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CommonListboxComponent),
    multi: true
  }]
})
export class CommonListboxComponent implements OnInit, ControlValueAccessor {
  selectedItemcheck: any;
  allValues:number = 0;
  @Input() dragdata:any;
  @Input() set dataavailable(items: Array<{}>) {
    this.availableItems = [...(items || []).map((item: {}, index: number) => ({
      value: item[this.valueField].toString(),
      text: item[this.textField],
      carrier_Code: item[this.valueField].toString(),
      carrier_Name: item[this.textField],
      shipper_Code: item[this.valueField].toString(),
      shipper_Name: item[this.textField],
      ship_Point_Code: item[this.valueField].toString(),
      citystate: item[this.textField],
      UserAccountId : item[this.selectField]
    }))];
    this.onavailableValue.emit(this.availableItems.length);
    if(items == undefined){
      this.onallValue.emit(this.allValues);
    }
    else{
      this.onallValue.emit(items.length);
    }
    this.onAvailableDashboard.emit(this.availableItems);
  };

  @Input() set dataselected(items: Array<{}>) {
    this.selectedItems = [...(items || []).map((item: {}, index: number) => ({
      value: item[this.valueField].toString(),
      text: item[this.textField],
      carrier_Code: item[this.valueField].toString(),
      carrier_Name: item[this.textField],
      shipper_Code: item[this.valueField].toString(),
      shipper_Name: item[this.textField],
      ship_Point_Code: item[this.valueField].toString(),
      citystate: item[this.textField],
      UserAccountId : item[this.selectField]
    }))];
    this.onselectedValue.emit(this.selectedItems.length);
    this.onSelectedDashboard.emit(this.selectedItems);
    this.onAvailableDashboard.emit(this.availableItems);
    
  };

  @Input() set availableSearch(searchTerm: string) {
    this.searchTermAvailable = searchTerm;
    this.availableSearchInputControl.setValue(searchTerm);
  };

  @Input() set selectedSearch(searchTerm: string) {
    this.searchTermSelected = searchTerm;
    this.selectedSearchInputControl.setValue(searchTerm);
  };

  @Input() valueField: string;
  @Input() textField: string;
  @Input() selectField: string;
  @Input() title: string;
  @Input() debounceTime = 500;
  @Input() moveAllButton = true;
  @Input() availableFilterPlaceholder: string;
  @Input() selectedFilterPlaceholder: string;

  @Output() onSelectedDashboard: EventEmitter<any> = new EventEmitter<any>();
  @Output() onavailableValue: EventEmitter<any> = new EventEmitter<any>();
  @Output() onselectedValue: EventEmitter<any> = new EventEmitter<any>();
  @Output() onallValue: EventEmitter<any> = new EventEmitter<any>();
  @Output() onAvailableDashboard: EventEmitter<any> = new EventEmitter<any>();

  searchTermAvailable = '';
  searchTermSelected = '';
  availableItems: Array<IListBoxItem> = [];
  selectedItems: Array<IListBoxItem> = [];
  listBoxForm: FormGroup;
  availableListBoxControl: FormControl = new FormControl();
  selectedListBoxControl: FormControl = new FormControl();
  availableSearchInputControl: FormControl = new FormControl();
  selectedSearchInputControl: FormControl = new FormControl();
  filteredAvailableItems: Array<IListBoxItem> = [];
  filteredSelectedItems: Array<IListBoxItem> = [];

  // control value accessors
  _onChange = (_: any) => { };
  _onTouched = () => { };

  constructor(public fb: FormBuilder, private helperService: HelperService) {

    this.listBoxForm = this.fb.group({
      availableListBox: this.availableListBoxControl,
      selectedListBox: this.selectedListBoxControl,
      availableSearchInput: this.availableSearchInputControl,
      selectedSearchInput: this.selectedSearchInputControl
    });
  }

  //Page load event
  ngOnInit(): void {
    this.availableSearchInputControl
      .valueChanges
      .pipe(debounceTime(this.debounceTime))
      .pipe(distinctUntilChanged())
      .subscribe((search: string) => this.searchTermAvailable = search);
    this.selectedSearchInputControl
      .valueChanges
      .pipe(debounceTime(this.debounceTime))
      .pipe(distinctUntilChanged())
      .subscribe((search: string) => this.searchTermSelected = search);
  }

  //Move all selected items to available
  moveAllItemsToAvailable(): void {
    if (!this.selectedItems.length) {
      return;
    }
    if(this.searchTermSelected.trim() !== '') {
      this.filterSelectedArray();
      if(this.filteredSelectedItems.length > 0) {
        this.moveMarkedSelectedItemsToAvailable();
        return;
      }
    }
    this.availableItems = [...this.availableItems, ...this.selectedItems];
    this.selectedItems = [];
    this.filteredSelectedItems = [];
    this.onselectedValue.emit(this.selectedItems.length);
    this.onavailableValue.emit(this.availableItems.length);
    this.selectedListBoxControl.setValue([]);
    this.writeValue([]);
    this.onSelectedDashboard.emit(this.selectedItems);
    this.onAvailableDashboard.emit(this.availableItems);
  }

  //Move all available items to selected
  moveAllItemsToSelected(): void {
     	if (!this.availableItems.length) {
     	return;
     	}
      if(this.searchTermAvailable.trim() !== '') {
        this.filterAvailableArray();
        if(this.filteredAvailableItems.length > 0) {
          this.moveMarkedAvailableItemsToSelected();
          return;
        }
      }
     	this.selectedItems = [...this.selectedItems, ...this.availableItems];
     	this.availableItems = [];
      this.filteredAvailableItems = [];
      this.onselectedValue.emit(this.selectedItems.length);
      this.onavailableValue.emit(this.availableItems.length);  	
     	this.availableListBoxControl.setValue([]);
      this.writeValue([]);
      this.onSelectedDashboard.emit(this.selectedItems);
      this.onAvailableDashboard.emit(this.availableItems);
  }   

  //Move available items to selected
  moveMarkedAvailableItemsToSelected(): void {
    this.selectedItemcheck = [...this.selectedItems,
    ...intersectionwith(this.availableItems, this.availableListBoxControl.value,
      (item: IListBoxItem, value: string) => item.value === value)];
      this.selectedItems = this.selectedItemcheck;
      // now filter available items to not include marked values
      this.availableItems = [...differenceWith(this.availableItems, this.availableListBoxControl.value,
        (item: IListBoxItem, value: string) => item.value === value)];
    this.onselectedValue.emit(this.selectedItems.length);
    this.onavailableValue.emit(this.availableItems.length);
    this.availableListBoxControl.setValue([]);
    this.availableSearchInputControl.setValue('');
    this.writeValue(this.getValues());
    this.onSelectedDashboard.emit(this.selectedItems);
    this.onAvailableDashboard.emit(this.availableItems);
  }

  //Move selected items to available
  moveMarkedSelectedItemsToAvailable(): void {
    this.availableItems = [...this.availableItems,
    ...intersectionwith(this.selectedItems, this.selectedListBoxControl.value,
      (item: IListBoxItem, value: string) => item.value === value)];
    // now filter available items to not include marked values
    this.selectedItems = [...differenceWith(this.selectedItems, this.selectedListBoxControl.value,
      (item: IListBoxItem, value: string) => item.value === value)];
    this.onselectedValue.emit(this.selectedItems.length);
    this.onavailableValue.emit(this.availableItems.length);
    this.onallValue.emit(this.availableItems.length);
    this.selectedListBoxControl.setValue([]);
    this.selectedSearchInputControl.setValue('');
    this.writeValue(this.getValues());
    this.onSelectedDashboard.emit(this.selectedItems);
    this.onAvailableDashboard.emit(this.availableItems);
  }


  trackByValue(index: number, item: {}): string {
    return item[this.valueField];
  }

  writeValue(value: any): void {
    if (this.selectedItems && value && value.length > 0) {
      this.selectedItems = [...this.selectedItems,
      ...intersectionwith(this.availableItems, value, (item: IListBoxItem, val: string) => item.value === val)];
      this.availableItems = [...differenceWith(this.availableItems, value,
        (item: IListBoxItem, val: string) => item.value === val)];
    }
    this._onChange(value);
  }

  registerOnChange(fn: (_: any) => {}): void {
    this._onChange = fn;
  }

  registerOnTouched(fn: () => {}): void {
    this._onTouched = fn;
  }

  private getValues(): string[] {
    return (this.selectedItems || []).map((item: IListBoxItem) => item.value);
  }

  //Filter Available array
  private filterAvailableArray() {
    if (this.searchTermAvailable.trim() === '') {
      return;
    }
    else {
      this.filteredAvailableItems = this.availableItems.filter((item: {}) => (item["text"].toString().toLowerCase().search(this.searchTermAvailable.toLowerCase().trim()) >= 0) || 
      (item["value"].toString().toLowerCase().search(this.searchTermAvailable.toLowerCase().trim()) >= 0));       

      const checkedOptions = this.filteredAvailableItems
     .map((v, i) => v ? this.filteredAvailableItems[i].value : null)
     .filter(v => v !== null);

      this.availableListBoxControl.setValue(checkedOptions);
    }    
  }

  //Filter Selected array
  private filterSelectedArray() {
    if (this.searchTermSelected.trim() === '') {
      return;
    }
    else {
      this.filteredSelectedItems = this.selectedItems.filter((item: {}) => (item["text"].toString().toLowerCase().search(this.searchTermSelected.toLowerCase().trim()) >= 0) || 
        (item["value"].toString().toLowerCase().search(this.searchTermSelected.toLowerCase().trim()) >= 0));       

      const checkedOptions = this.filteredSelectedItems
     .map((v, i) => v ? this.filteredSelectedItems[i].value : null)
     .filter(v => v !== null);

      this.selectedListBoxControl.setValue(checkedOptions);
    }    
  }

}

export interface IListBoxItem {
  value: string;
  text:string;
  carrier_Code: string;
  carrier_Name: string;
  shipper_Code: string;
  shipper_Name: string;
  ship_Point_Code: string;
  citystate: string;
}
