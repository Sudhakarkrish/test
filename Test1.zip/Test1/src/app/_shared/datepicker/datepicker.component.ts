
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent implements OnInit {
@Input() calendar;
model: string;
@Output() onDateChange: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {    
  }

  onChange(event){
    this.onDateChange.emit(event);
  }
}
