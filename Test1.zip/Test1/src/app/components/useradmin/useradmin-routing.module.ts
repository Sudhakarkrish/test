import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CarrierdetailComponent } from './carrier/carrierdetail/carrierdetail.component';
import { ShipperdetailComponent } from './shipper/shipperdetail/shipperdetail.component';
import { AdminComponent } from './admin/admin.component';
import { UserpermissionComponent } from './userpermission/userpermission.component';
import { AddUserShipperComponent } from './shipper/add-user-shipper/add-user-shipper.component';
import { AddNewCarrierComponent } from './carrier/addnewcarrier/addnewcarrier.component';
import { AddNewInternalUserComponent } from './addnewinternaluser/addnewinternaluser.component';
import { ShipperstepperComponent } from './stepper/shipperstepper/shipperstepper.component';
import { CarrierstepperComponent } from './stepper/carrierstepper/carrierstepper.component';
import { InternalstepperComponent } from './stepper/internalstepper/internalstepper.component';
import { ShipPointsComponent } from './ship-points/ship-points.component';
import { MetricfilterComponent } from './metricfilter/metricfilter.component';

const routes: Routes = [
    { path: 'SelectCarriers', component: CarrierdetailComponent },
    { path: 'SelectShippers', component: ShipperdetailComponent },
    { path: 'UserAdminMenu', component: AdminComponent },
    { path: 'Carrier', component: CarrierdetailComponent },
    { path: 'UserPermission', component: UserpermissionComponent },
    { path: 'AddUserShipper', component: AddUserShipperComponent },
    { path: 'AddNewCarrier', component: AddNewCarrierComponent },
    { path: 'AddNewInternalUser', component: AddNewInternalUserComponent },
    { path: 'AdminShipper', component: ShipperstepperComponent },
    { path: 'AdminCarrier', component: CarrierstepperComponent },
    { path: 'AdminInternal', component: InternalstepperComponent },
    { path: 'AdminShipPoint', component: ShipPointsComponent },
    { path: 'MetricFilter', component: MetricfilterComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserAdminRoutingModule { }
