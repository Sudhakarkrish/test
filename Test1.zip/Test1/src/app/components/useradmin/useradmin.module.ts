import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AddNewInternalUserComponent } from './addnewinternaluser/addnewinternaluser.component';
import { AdminComponent } from './admin/admin.component';
import { AddNewCarrierComponent } from './carrier/addnewcarrier/addnewcarrier.component';
import { CarrierdetailComponent } from './carrier/carrierdetail/carrierdetail.component';
import { MultiSelectDropdownComponent } from './multi-select-dropdown/multi-select-dropdown.component';
import { ShipPointsComponent } from './ship-points/ship-points.component';
import { AddUserShipperComponent } from './shipper/add-user-shipper/add-user-shipper.component';
import { ShipperdetailComponent } from './shipper/shipperdetail/shipperdetail.component';
import { CarrierstepperComponent } from './stepper/carrierstepper/carrierstepper.component';
import { InternalstepperComponent } from './stepper/internalstepper/internalstepper.component';
import { ShipperstepperComponent } from './stepper/shipperstepper/shipperstepper.component';
import { UserpermissionComponent } from './userpermission/userpermission.component';
import { UserAdminRoutingModule } from './useradmin-routing.module';
import { ModalpopupComponent } from 'src/app/_shared/modalpopup/modalpopup.component';
import { SharedRoutingModule } from 'src/app/_shared/shared-routing.module';
import { SharedModule } from 'src/app/_shared/shared.module';
import { MetricfilterComponent } from './metricfilter/metricfilter.component';

@NgModule({
  declarations: [
    AddNewInternalUserComponent,
    AdminComponent,        
    AddNewCarrierComponent,
    CarrierdetailComponent,
    MultiSelectDropdownComponent, 
    ShipPointsComponent, 
    AddUserShipperComponent,
    ShipperdetailComponent,
    CarrierstepperComponent,
    InternalstepperComponent,  
    ShipperstepperComponent,
    UserpermissionComponent,
    ModalpopupComponent,
    MetricfilterComponent
  ],
  imports: [
    CommonModule,
    UserAdminRoutingModule,
    FormsModule,
    SharedRoutingModule,
    ReactiveFormsModule,
    NgbModule,
    SharedModule
  ],
  entryComponents: [ShipPointsComponent, ModalpopupComponent],
  exports: [
    AddNewInternalUserComponent,
    AdminComponent,        
    AddNewCarrierComponent,
    CarrierdetailComponent,
    MultiSelectDropdownComponent, 
    ShipPointsComponent, 
    AddUserShipperComponent,
    ShipperdetailComponent,
    CarrierstepperComponent,
    InternalstepperComponent,  
    ShipperstepperComponent,
    UserpermissionComponent,
    ModalpopupComponent,
    MetricfilterComponent   
  ]
})
export class UserAdminModule { }
