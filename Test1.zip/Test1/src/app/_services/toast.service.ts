import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { Toast, ToastType } from '../_models/toast';
import { filter } from 'rxjs/operators';


@Injectable()
export class ToastService {
    private subject = new Subject<any>();
    private keepAfterNavigationChange = false;

    constructor(private router: Router) {
        // clear alert message on route change
        router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                if (this.keepAfterNavigationChange) {
                    // only keep for a single location change
                    this.keepAfterNavigationChange = false;
                } else {
                    // clear alert
                    this.subject.next(new Toast());
                }
            }
        });
    }

    getAlert(alertId?: string): Observable<any> {
        return this.subject.asObservable().pipe(filter((x: Toast) => x && x.alertId === alertId));
    }

     // convenience methods
     success(message: string,keepAfterNavigationChange:boolean) {
        this.alert(new Toast({ message, type: ToastType.Success,keepAfterNavigationChange }));
    }

    error(message: string,keepAfterNavigationChange:boolean) {
        this.alert(new Toast({ message, type: ToastType.Error,keepAfterNavigationChange }));
    }

    info(message: string,keepAfterNavigationChange:boolean) {
        this.alert(new Toast({ message, type: ToastType.Info,keepAfterNavigationChange }));
    }

    warn(message: string,keepAfterNavigationChange:boolean) {
        this.alert(new Toast({ message, type: ToastType.Warning,keepAfterNavigationChange }));
    }

    // main alert method    
    alert(alert: Toast) {
        this.keepAfterNavigationChange = alert.keepAfterNavigationChange;
        this.subject.next(alert);
    }

    // clear alerts
    clear(alertId?: string) {
        this.subject.next(new Toast({ alertId }));
    }
}