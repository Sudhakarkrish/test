import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { tap, catchError ,map } from 'rxjs/operators';
import { HelperService } from './helper.service';
import { Constants } from "../_global/constants";
import { TableState } from '../_models/table-state';
import { AdminList,UserAdmin } from '../_models/admin';
import { ShipperList } from '../_models/shipper';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient, private helperService: HelperService, private constants: Constants) { }

    GetAdminRegisterUser(filter:any, type: any, table:TableState): Observable<any>{
      let environmenturl = environment.apiUrl + this.constants.apiadminRegisteruser;
      let url =`${environmenturl}/${filter}/${type}/Fields?&Page=${table.page}&PageSize=${table.pageSize}&SortBy=${table.sortColumn}&SortDirection=${table.sortDirection}`;
      return this.http.get<any>(url).pipe(
        tap(_ => this.helperService.log('Fetched GetAdminuserlist')), 
        catchError(this.helperService.handleError<any>('GetAdminuserlist'))
      );
    }
    GetAdminInternalUser(filter:any, table:TableState): Observable<any>{
      let environmenturl = environment.apiUrl + this.constants.apiadminInternaluser;
      let url =`${environmenturl}/${filter}/Fields?&Page=${table.page}&PageSize=${table.pageSize}&SortBy=${table.sortColumn}&SortDirection=${table.sortDirection}`;
      return this.http.get<any>(url).pipe(
        tap(_ => this.helperService.log('Fetched GetAdminuserlist')), 
        catchError(this.helperService.handleError<any>('GetAdminuserlist'))
      );
    }
    GetAdminUnRegisterUser(filter:any, type: any, table:TableState): Observable<any>{
      let environmenturl = environment.apiUrl + this.constants.apiadminUnRegisteruser;
      let url =`${environmenturl}/${filter}/${type}/Fields?&Page=${table.page}&PageSize=${table.pageSize}&SortBy=${table.sortColumn}&SortDirection=${table.sortDirection}`;
      return this.http.get<any>(url).pipe(
        tap(_ => this.helperService.log('Fetched GetAdminuserlist')), 
        catchError(this.helperService.handleError<any>('GetAdminuserlist'))
      );
    }

     DisableDelete(filter:AdminList, command: any, servicelocation:any,internal:any,staging:any): Observable<any>{
      let environmenturl = environment.apiUrl + this.constants.apiadminDisableDelete;
      let url =`${environmenturl}/${command}/${servicelocation}/${internal}/${staging}`;
      return this.http.post<any>(url ,filter).pipe(map(data => {
        return data;
    }));
    }

    GetAdminAllUser(filter:any, value:any, flag:any,name:any, table:TableState): Observable<any>{
      let environmenturl = environment.apiUrl + this.constants.apiadminAlluser;
      let url =`${environmenturl}/${filter}/${value}/${flag}/${name}/Fields?&Page=${table.page}&PageSize=${table.pageSize}&SortBy=${table.sortColumn}&SortDirection=${table.sortDirection}`;
      return this.http.get<any>(url).pipe(
        tap(_ => this.helperService.log('Fetched GetAdminuserlist')), 
        catchError(this.helperService.handleError<any>('GetAdminuserlist'))
      );
    }

    GetExternalAuthenticatorList(): Observable<any> {
      let url = environment.apiUrl + this.constants.apiadminGetExternalAuthenticators;
      return this.http.get<any>(url).pipe(
          tap(_ => this.helperService.log('Fetched External Authenticator List')),
          catchError(this.helperService.handleError<any>('GetExternalAuthenticatorList'))
      );
    }

    GetExternalAuthenticationProviderList(id: any): Observable<any> {      
      let apiurl = environment.apiUrl + this.constants.apiadminGetExternalAuthenticationProviderMapping;
      let url = `${apiurl}/${id}`;
      return this.http.get<any>(url).pipe(
          tap(_ => this.helperService.log('Fetched External Authentication ProviderList List')),
          catchError(this.helperService.handleError<any>('GetExternalAuthenticationProviderList'))
      );
    }

    GetUserAdmin(id: any,type:any,reg:any): Observable<any> {
      let apiurl = environment.apiUrl + this.constants.apigetuserAdmin;
      let url = `${apiurl}/${id}/${type}/${reg}`;
      return this.http.get<any>(url).pipe(
          tap(_ => this.helperService.log('Fetched GetAdminUserDetails')),
          catchError(this.helperService.handleError<any>('GetAdminUserDetails'))
      );
    }

    RegisterUser(useradmin:UserAdmin): Observable<any>{
      let url = environment.apiUrl + this.constants.apiRegisterUser;
      return this.http.post<any>(url ,useradmin).pipe(map(data => {
        return data;
    }));
    }

    UpdateUser(useradmin:UserAdmin): Observable<any>{
      let url = environment.apiUrl + this.constants.apiUpdateUser;
      return this.http.post<any>(url ,useradmin).pipe(map(data => {
        return data;
    }));
    }
    
    CheckPriviledge(id:any): Promise<boolean> {
      let environmenturl = environment.apiUrl + this.constants.apiCheckPriviledgeIds;
      let url =`${environmenturl}/${id}`
      const promise = this.http.get<any>(url)
        .toPromise()
        .then(data => {
          return data.Result;
        });
      return promise;
    }  

   async GetVerifyUser(email:any) {
     let apiurl = environment.apiUrl + this.constants.apiGetVerifyMail;
     let url = `${apiurl}/${email}`;   
     return await this.http.get<any>(url).toPromise();
  }

DeleteUser(filter:AdminList): Observable<any>{
  let environmenturl = environment.apiUrl + this.constants.apiadminDeleteUsers;
  let url =`${environmenturl}`;
  return this.http.post<any>(url ,filter).pipe(map(data => {
    return data;
 }));
 }

 GetAdvanceFilter(datavalue:any, type:any, table:TableState,flag:any): Observable<any> {
  let apiUrl ;
  if(type == 'S')
  {
    apiUrl = environment.apiUrl + this.constants.apigetAdvanceShipperFilter ;
  }
  else if(type == 'C'){
    apiUrl = environment.apiUrl + this.constants.apigetAdvanceCarrierFilter;
  }
  let url = `${apiUrl}/${type}/${flag}/Fields?&Page=${table.page}&PageSize=${table.pageSize}&SortBy=${table.sortColumn}&SortDirection=${table.sortDirection}`;
  return this.http.post<any>(url ,datavalue).pipe(map(data => {
    return data;
 }));
}

}
