import { Component, OnInit,Input } from '@angular/core';
import {Toast,ToastType} from '../../_models/toast';
import {ToastService} from '../../_services/toast.service';

@Component({
  selector: 'app-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.css']
})
export class ToastComponent implements OnInit {
  @Input() id: string;
  alerts: Toast[] = [];

  constructor(private toastService: ToastService) { }

  ngOnInit() {
    this.GetAlert();
  }

  GetAlert(){
    this.toastService.getAlert(this.id).subscribe((alert: Toast) => {
      if (!alert.message) {
          // clear alerts when an empty alert is received
          this.alerts = [];
          return;
      }

      // add alert to array
      this.alerts.push(alert);
      setTimeout(() => this.alerts.pop(), 5000);
  });
  }

  removeAlert(alert: Toast) {
    this.alerts = this.alerts.filter(x => x !== alert);
}

cssClass(toast: Toast) {
    if (!alert) {
        return;
    }

    // return css class based on alert type
    switch (toast.type) {
        case ToastType.Success:
            return 'alert alert-success';
        case ToastType.Error:
            return 'alert alert-danger';
        case ToastType.Info:
            return 'alert alert-info';
        case ToastType.Warning:
            return 'alert alert-warning';
    }
}
}
