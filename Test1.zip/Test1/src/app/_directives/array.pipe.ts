import { Pipe, PipeTransform } from '@angular/core';
declare var require: any;
const orderby = require('lodash.orderby');

export class SortOptions {
  static direction: {
    ASC: string,
    DESC: string
  } = {
      ASC: 'ASC',
      DESC: 'DESC'
    };
}

@Pipe({
  name: 'arraySort'
})

export class ArraySortPipe implements PipeTransform {

  transform(array: Array<{}>, args: string[]): Array<string> | Array<{}> {

    array = array || [];

    if (typeof args === 'undefined' || args.length !== 2) {
      return array;
    }

    const [key, direction] = args;

    if (direction !== SortOptions.direction.ASC && direction !== SortOptions.direction.DESC) {
      return array;
    }

    // if there is no key we assume item is of string type
    return orderby(array, (item: {} | string) => item.hasOwnProperty(key) ? item[key] : item, direction.toLowerCase());
  }
}


@Pipe({
  name: 'arrayFilter'
})
export class ArrayFilterPipe implements PipeTransform {

  transform(array: Array<{}>, args: string[]): Array<string> | Array<{}> {

    array = array || [];

    if (typeof args === 'undefined' || args.length !== 2) {
      return array;
    }

    const [key, searchTerm] = args;

    if (searchTerm.trim() === '') {
      return array;
    }

    //return array.filter((item: {}) => item[key].toString().toLowerCase().search(searchTerm.toLowerCase().trim()) >= 0);    
    
    return array.filter((item: {}) => (item[key].toString().toLowerCase().search(searchTerm.toLowerCase().trim()) >= 0) || 
     (item["value"].toString().toLowerCase().search(searchTerm.toLowerCase().trim()) >= 0));    
   
  }
}
