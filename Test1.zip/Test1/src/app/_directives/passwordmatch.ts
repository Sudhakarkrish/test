import { FormGroup} from '@angular/forms';

// custom validator to check that two fields match
export function MustMatch(controlName: string, matchingControlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];

        if (matchingControl.errors && !matchingControl.errors.mustMatch) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ mustMatch: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
}


export function CheckPassword(controlName: string) {
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        if (control.errors && !control.errors.checkPassword) {
            // return if another validator has already found an error on the matchingControl
            return;
        }

        // set error on matchingControl if validation fails
        if (CheckPasswordValue(control.value) == false) {
            control.setErrors({ checkPassword: true });
        } else {
            control.setErrors(null);
        }
    }

    
}


export function CheckPasswordValue(MyPassword):boolean {

	MyPassword = MyPassword.toUpperCase();

	var iLetter = 0;
	var iNumber = 0;
	var iOther = 0;
	var iTotal = 0;

	for (var i = 0; i < MyPassword.length; i++) {
		if (MyPassword.charCodeAt(i) >= 65 && MyPassword.charCodeAt(i) <= 90) {
			iLetter = 1;
		}
		if (MyPassword.charCodeAt(i) >= 48 && MyPassword.charCodeAt(i) <= 57) {
			iNumber = 1;
		}
		if ((MyPassword.charCodeAt(i) >= 0 && MyPassword.charCodeAt(i) <= 47)
			|| (MyPassword.charCodeAt(i) >= 58 && MyPassword.charCodeAt(i) <= 64)
			|| (MyPassword.charCodeAt(i) >= 91)) {
			iOther = 1;
		}
	}

	iTotal = iLetter + iNumber + iOther;

	if (iTotal < 2) {
		return false;
	}
	else {
		return true;
	}
}

