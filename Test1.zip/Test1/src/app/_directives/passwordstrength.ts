import { Component, OnChanges, Input, SimpleChange, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'password-strength-bar',
  styles: [`
  .passwordStrength {
    height: 5px;
    display: block;
  }
  
  .strength0 {
    width: 250px;
    background: #DDD;
  }
  
  .strength1 {
    width: 40px;
    background: #F00;
  }
  
  .strength2 {
    width: 75px;
    background: #F90;
  }
  
  .strength3 {
    width: 150px;
    background: #FF0;
  }
  
  .strength4 {
    background: #9F0;
    width: 200px;
  }
  .strength5 {
    background: #0F0;
    width: 250px;
  }
  `],
  template: `
  <div>
  <label for="passwordStrength"><span>Password strength:&nbsp;</span></label>
  <span [innerHtml]="strengthName"></span>
  <div class="passwordStrength {{strengthcolor}}" style="border-radius:4px; margin-left:8px"></div>
 </div>
  `
})
export class PasswordStrengthBarComponent implements OnChanges {
  @Input() passwordvalue: string;
  strengthcolor: string ='strength0';
  strengthName: string = 'Very Weak';

  constructor() {
   
  }

  ngOnChanges() {    
    this.passwordStrength();
  }

  passwordStrength()
  {
    var value = this.passwordvalue
    var desc = new Array();
    desc[0] = "Very Weak";
    desc[1] = "Very Weak";
    desc[2] = "Weak";
    desc[3] = "Medium";
    desc[4] = "Good";
    desc[5] = "Very Good";
    var score = 0;

    //if password bigger than 10 give 1 point

    if (value.length > 8) score++;

    //if password has lower characters give 1 point

    if (value.match(/[a-z]/)) score++;

    //if password has uppercase characters give 1 point

    if (value.match(/[A-Z]/)) score++;

    //if password has at least one number give 1 point

    if (value.match(/[0-9]/)) score++;

    //if password has at least one special character give 1 point

    if (value.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)) score++;

    this.strengthName = desc[score];
    this.strengthcolor = "strength" + score;
  }
}
