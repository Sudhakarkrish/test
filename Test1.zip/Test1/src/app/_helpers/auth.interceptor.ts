import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../_services';
import { environment } from 'src/environments/environment';
import { Constants } from '../_global/constants';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService, private constants: Constants){}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
      // add authorization header with idp token if available     
      let token = sessionStorage.getItem('token');
      if (token && request.url != environment.webuiApiUrl + this.constants.identityApi) {
            request = request.clone({
                setHeaders: { 
                  Authorization: `Bearer ${token}`, 
                }
            });
        }
        return next.handle(request);
    }
}
