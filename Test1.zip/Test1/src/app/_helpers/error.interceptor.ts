import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { AuthenticationService } from '../_services';
import { HttpStatusCode } from '../_global/enum';
import { ToastService } from '../_services/toast.service';
import { BaseModel } from '../_models/base-model';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService, private toastService: ToastService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return next.handle(request).pipe(catchError(err => {
            if (err.status === 401) {
                // auto logout if 401 response returned from api
                this.authenticationService.logout();
                location.reload(true);
            }
            if (err.status !== HttpStatusCode.CONFLICT && err.status !== HttpStatusCode.NOT_FOUND && err.status !== HttpStatusCode.UNPROCESSABLE_ENTITY && err.status !== HttpStatusCode.OK) {
                this.toastService.error("Error occurred. Please contact administrator.", false); 
            } 
            if(err.error && err.error.Result){
                let model = new BaseModel();
                model.StatusCode = err.error.StatusCode;
                model.ErrorMessage = err.error.Result.Message;
                return throwError(model);
            }      
            return throwError(err.error);
        }));
    }
}