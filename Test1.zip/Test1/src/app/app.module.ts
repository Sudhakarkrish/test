import { NgModule, APP_INITIALIZER }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule , ReactiveFormsModule }    from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgIdleKeepaliveModule} from '@ng-idle/keepalive';
import { LocationStrategy, HashLocationStrategy} from '@angular/common';
import { AuthGuard } from './_guards';
import { AuthInterceptor, ErrorInterceptor } from './_helpers';
import { AlertService, AuthenticationService } from './_services';
import { HomeComponent } from './components/home-dashboard/home/home.component';
import { DashboardComponent } from './components/home-dashboard/dashboard/dashboard.component';
import { DragdropComponent } from './components/home-dashboard/dragdrop/dragdrop.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule, NgbActiveModal, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { TableauService } from './_services/tableau.service';
import { UserService } from './_services/user.service';
import { Constants } from './_global/constants';
import { LogoutComponent} from './components/login/logout/logout.component';
import { SessiontimeoutComponent } from './components/login/sessiontimeout/sessiontimeout.component';
import { MessageService } from './_services/message.service';
import { ForgotPasswordService } from './_services/forgotpassword.service';
import { ChangePasswordService } from './_services/changepassword.service';
import { ToastService } from './_services/toast.service';
import { AdminService } from './_services/admin.service';
import { UserpermissionService } from './_services/userpermission.service';
import { ShipPointService } from './_services/shippoints.service';
import { SharedModule } from './_shared/shared.module';
import { ShippermodalComponent } from './components/shipper/shippermodal/shippermodal.component';
import { ApplayoutComponent } from './_layout/applayout/applayout.component';
import { TableauuseradminService } from './_services/tableauuseradmin.service';
import { UicommoncomponentsModule } from 'uicommoncomponents';
import { ChangepasswordnewComponent } from './components/changepasswordnew/changepasswordnew.component';
import { CustomNgbDateParserFormatter } from './_directives/custom.format';

export function init_app(authService: AuthenticationService) {
    return () => authService.getToken();
}

@NgModule({
  imports: [
      BrowserModule,
      FormsModule,
      ReactiveFormsModule,
      HttpClientModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      NgbModule,
      SharedModule,
      UicommoncomponentsModule,
      NgIdleKeepaliveModule.forRoot()
  ],
  declarations: [
      AppComponent,
      HomeComponent,    
      DashboardComponent,
      DragdropComponent,      
      LogoutComponent,
      SessiontimeoutComponent,   
      ShippermodalComponent,
      DashboardComponent, ApplayoutComponent , ChangepasswordnewComponent
  ],
  entryComponents: [LogoutComponent, SessiontimeoutComponent, ShippermodalComponent],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy},
      AuthGuard,
      AlertService,
      AuthenticationService,     
      TableauService,
      UserService,
      Constants,
      MessageService,
      ForgotPasswordService,
      ChangePasswordService,
      ToastService,
      AdminService,
      ShipPointService,
      UserpermissionService,
      TableauuseradminService,
      NgbActiveModal,
      { provide: APP_INITIALIZER, useFactory: init_app, deps: [AuthenticationService], multi: true }, 
      { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
      { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
      { provide: NgbDateParserFormatter, useFactory: () => new CustomNgbDateParserFormatter('dd-MMM-yyyy')}
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
