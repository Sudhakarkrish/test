import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private router: Router) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
        if(sessionStorage.getItem('changepassword') == "true" || parseInt(sessionStorage.getItem('passwordExpiration')) < 0){
            sessionStorage.setItem('changepassword', "false");
            this.router.navigate(['/ChangePassword']);
            return false;
        }
        else{
            // // not logged in so redirect to login page with the return url
            // this.router.navigate(['/login'], { queryParams: { returnUrl: state.url }});
            return true;
        }        
    }

   
}