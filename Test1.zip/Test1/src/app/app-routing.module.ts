import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { HomeComponent } from './components/home-dashboard/home/home.component';
import { AuthGuard } from './_guards';
import { DashboardComponent } from './components/home-dashboard/dashboard/dashboard.component';
import { ApplayoutComponent } from './_layout/applayout/applayout.component';
import { ChangepasswordnewComponent } from './components/changepasswordnew/changepasswordnew.component';

const routes: Routes = [ 
  { path : '' , component : ApplayoutComponent ,canActivate: [AuthGuard], 
  children: [  
    { path: '', component: DashboardComponent},
    { path: 'Home', component: HomeComponent},
    { path:'notification', 
      loadChildren: './components/notifications/notification.module#NotificationModule'
    },
    { path:'userprofile', 
      loadChildren: './components/userprofile/userprofile.module#UserProfileModule'
    },           
    { path:'admin', 
      loadChildren: './components/useradmin/useradmin.module#UserAdminModule'
    },  
    { path:'password', 
      loadChildren: './components/password/password.module#PasswordModule'
    },  
    { path:'tableauadmin', 
    loadChildren: './components/tableauadmin/tableauadmin.module#TableauAdminModule'
    }  
  ]},
  { path : 'ChangePassword' , component : ChangepasswordnewComponent },
  { path: '**', redirectTo: 'Home' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})

export class AppRoutingModule { }
