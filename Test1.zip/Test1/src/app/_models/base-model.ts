export class BaseModel {
    StatusCode: number;
    ErrorMessage: string;   
}