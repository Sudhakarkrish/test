import { BaseModel } from './base-model';


export class MenuList extends BaseModel{
  navItems : Menu[];
  displayName : string; 
}

export class MenuItemDetail{
  linkUrl: string;
  text: string;
  isScriptMenu: boolean;
}

export class Menu{
    name : string;
    menuIcon: string;
    active: boolean = false;
    menuGroup: MenuGroup[];
}

export class MenuGroup{
    groupName: string;
    linkUrl: string;
    menuItems: MenuItemDetail
} 
