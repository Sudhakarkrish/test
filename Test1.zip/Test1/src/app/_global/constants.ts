import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable()
export class Constants {
    

    public readonly apiHome: string ="/home";
    public readonly apiUser: string ="/userprofile";
    public readonly apimessage: string ="/message";
    public readonly apireport: string ="/report";
    public readonly apiTableau: string ="/tableau";
    public readonly apiUserPermission: string ="/UserPermission";
    public readonly apiUserPermissionShipCount: string ="/UserPermission/GetShipPointCount";
    public readonly footerLink:Array<any> = [{name:'Privacy Policy',link:'http://www.cassinfo.com/en/Corporate/privacy-policy.aspx'},
    {name:'Cass Home Page',link:'https://www.cassinfo.com/'},
    {name:'Freight Index',link:'https://www.cassinfo.com/frtindex.html'},
    {name:'Carrier Relations',link:'https://www.cassinfo.com/Corporate/Roles/Freight-Carrier.aspx'},
    {name:'RateMaker',link:'https://www.cassinfo.com/freight-audit-payment/services/freight-rating'},
    {name:'System Requirements',link:'/CassPort/Account/SystemRequirements'},
    {name:'Contact Us',link:'https://www.cassinfo.com/en/Corporate/Contact-Us.aspx'}];
    public readonly helpMenu:Array<any> = [{Name:'English',link: environment.envUrl + '/CISFBSYS/Login/Manuals/CassPortCarrierTraining,%20English%20edition.pdf'}
    ,{Name:'Spanish',link: environment.envUrl +'/CISFBSYS/Login/Manuals/CassPortCarrierTraining,Spanish%20edition.pdf'}];
    public readonly apiForgot: string ="/ForgotPassword";
    public readonly apiDashboard: string ="/Dashboard";
    public readonly mvchomeFooter: string ="/Home/VersionNo";
    public readonly apiChangePassword: string ="/ChangePassword";
    public readonly apiGetCountries: string ="/UserProfile/GetCountries";
    public readonly apiGetStates: string ="/UserProfile/GetStates";
    public readonly apiGetUserAccountDetails: string ="/UserProfile/GetUserAccount";    
    public readonly apiUserProfile: string ="/UserProfile";
    public readonly apiUpdateUserProfile: string ="/UserProfile/EditProfile";    
    public readonly exportSessionReport: string=  environment.envUrl +'/';
    public readonly tableauUsername: string ="Cognizant";
    public readonly tableauServer: string= environment.tableauEnv;
    public readonly apiResetPassword: string ="/ResetPassword";
    public readonly passwordresultFailed: string ="Your Password failed to update Please try again";
    public readonly passwordresultnotmatch: string ="Current Username and password combination did not match";
    public readonly passwordresultdidnotmeetReq: string ="Your Password did not meet the requirements please review them before proceeding";
    public readonly resetpasswordExpired: string ="Your Link is No longer Valid or Has Expired";
    public readonly apiCancelResetPassword: string ="/ResetPassword/CancelResetPassword";    
    public readonly emailPattern: string="^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$";
    public readonly phonePattern: string="^[0-9]{3}-[0-9]{3}-[0-9]{4}$";    
    public readonly postalPattern: string="^[0-9]+$";  
    public readonly namePattern: string="^[A-Za-z0-9]+$";    
    public readonly companyNamePattern: string="^[A-Za-z0-9]+$";   
    public readonly restrictSpacePattern: string="^[^\\s].*";  
    public readonly apiCarrier: string ="/Carrier";
    public readonly apiShipper: string ="/Shipper";
    public readonly apiShipPoint: string ="/ShipPoint";
    public readonly apiShipPointSearch: string ="/ShipPoint/GetShipPointSearch";
    public readonly apiadminRegisteruser: string ="/useradministration";
    public readonly apiadminInternaluser: string ="/useradministration/GetInternalUsers";
    public readonly apiadminUnRegisteruser: string ="/useradministration/UnregisteredUsers";
    public readonly apiadminDisableDelete: string ="/useradministration/DisableDelete";
    public readonly apiadminAlluser: string ="/useradministration/GetAllUsers";
    public readonly apiadminunlockuser: string ="/useradministration/GetUnlockUser";
    public readonly registeredCompanyType: Array<any> = [{text:'Shipper',value:'S'},{text:'Carrier',value:'C'},{text:'Unregistered Shipper',value:'US'},{text:'Unregistered Carrier',value:'UC'}];
    public readonly shipperCompanyType: Array<any> = [{text:'Shipper',value:'S'},{text:'Internal',value:'B'},{text:'Unregistered Shipper',value:'US'},{text:'Unregistered Carrier',value:'UC'}];
    public readonly carrierCompanyType: Array<any> = [{text:'Carrier',value:'C'},{text:'Internal',value:'B'},{text:'Unregistered Shipper',value:'US'},{text:'Unregistered Carrier',value:'UC'}];
    public readonly internalCompanyType: Array<any> = [{text:'Internal',value:'B'}];
    public readonly AllCompanyType: Array<any> = [{text:'All',value:'A'}];
    public readonly companyType: Array<any> = [{text:'Shipper',value:'S'},{text:'Carrier',value:'C'},{text:'Internal',value:'B'},{text:'Unregistered Shipper',value:'US'},{text:'Unregistered Carrier',value:'UC'}];
    public readonly apiadminGetExternalAuthenticators: string ="/useradministration/GetExternalAuthenticators";
    public readonly apiadminGetExternalAuthenticationProviderMapping: string ="/useradministration/GetExternalAuthenticationProviderMappings";
    public readonly chemoursUserType: Array<any> = [{text:'Chemours Corporate',value: 1}, {text:'Brokers/Forwarders',value:2},
                                                    {text:'Import International',value:3}, {text:'Export International',value:4},
                                                    {text:'SETD Terminals',value:5},{text:'Platform',value:6},
                                                    {text:'Divestiture',value:7},{text:'Chemours Site',value:8}]
    
    public readonly dupontUserType: Array<any> = [{text:'DuPont Corporate',value:1}, {text:'Brokers/Forwarders',value:2},
                                                    {text:'Import International',value:3}, {text:'Export International',value:4},
                                                    {text:'SETD Terminals',value:5},{text:'Platform',value:6},
                                                    {text:'Divestiture',value:7},{text:'DuPont Site',value:8}]    

    public readonly sFRClient4UserType: Array<any> = [{text:'Corteva Corporate',value:1}, {text:'Brokers/Forwarders',value:2},
                                                    {text:'Import International',value:3}, {text:'Export International',value:4},
                                                    {text:'SETD Terminals',value:5},{text:'Platform',value:6},
                                                    {text:'Divestiture',value:7},{text:'Corteva Site',value:8}]    
                                                    
    public readonly sFRClient5UserType: Array<any> = [{text:'Dow Corporate',value:1}, {text:'Brokers/Forwarders',value:2},
                                                    {text:'Import International',value:3}, {text:'Export International',value:4},
                                                    {text:'SETD Terminals',value:5},{text:'Platform',value:6},
                                                    {text:'Divestiture',value:7},{text:'Dow Site',value:8}]     
                                                    
    public readonly veoliaUserType: Array<any> = [{text:'Veolia Corporate',value:1}, {text:'Brokers/Forwarders',value:2},
                                                    {text:'Import International',value:3}, {text:'Export International',value:4},
                                                    {text:'SETD Terminals',value:5},{text:'Platform',value:6},
                                                    {text:'Divestiture',value:7},{text:'Veolia Site',value:8}]                                                       
    public readonly apiUserLogout: string = '/logout';
    public readonly apigetuserAdmin: string ="/useradministration/GetUserAdminDetails";    
    public readonly apiRegisterUser: string ="/useradministration/RegisterUser";
    public readonly apiUpdateUser: string ="/useradministration/UpdateUser";
    public readonly dupont: string ="DUPONT";
    public readonly chemours: string ="CHEMOURS";
    public readonly corteva: string ="SFRCLIENT4";
    public readonly dow: string ="SFRCLIENT5";
    public readonly veolia: string ="VEOLIA";
    public readonly addUserTypeShipper: Array<any> = [{text:'Shipper', value:'AdminShipper'}];
    public readonly addUserTypeCarrier: Array<any> = [{text:'Carrier', value:'AdminCarrier'}];
    public readonly addUserTypeInternal: Array<any> = [{text:'Internal User', value:'AdminInternal'}];
    public readonly AddNewUsersClients:Array<any> = [14];
    public readonly AddNewUsersCarriers:Array<any> = [15];
    public readonly RegisterUsers:Array<any> = [16];
    public readonly EditRegisteredUsers:Array<any> = [17];
    public readonly AddNewInternalUsers:Array<any> = [18];
    public readonly EditRegisteredInternalUsers:Array<any> = [19];
    public readonly CustomAdmin:Array<any> = [243];
    public readonly TableauAdmin:Array<any> = [244];
    public readonly AssignDashboard:Array<any> = [245];
    public readonly apiCheckPriviledgeIds: string ="/useradministration/GetCheckPriviledge";
    public readonly UnRegisterCompanyType: Array<any> = [{text:'Unregistered Shipper',value:'US'},{text:'Unregistered Carrier',value:'UC'}];
    public readonly RegisterShipperCompanyType: Array<any> = [{text:'Shipper',value:'S'}];
    public readonly RegisterCarrierCompanyType: Array<any> = [{text:'Carrier',value:'C'}];
    public readonly RegisterCompanyType: Array<any> = [{text:'Shipper',value:'S'},{text:'Carrier',value:'C'}];
    public readonly adminMenu:Array<any> = [15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,52,43,32,33,34,35,41,46,47,48,53,62,63,64,65,66,67,68,69,70,109,95];
    public readonly apiGetVerifyMail: string ="/useradministration/GetVerifyInternalUser";
    public readonly identityApi ="/api/identity";
    public readonly logoutApi ="/Account/Logout";
    public readonly apiTableauUserAdmin: string ="/tableauuseradmin";
    public readonly apiadminDeleteUsers: string ="/useradministration/DeleteUser";
    public readonly apiTableauSearchUserAdmin: string ="/tableauuseradmin/GetSearchUser";
    public readonly apiTableauDashboardType: string ="/tableauuseradmin/GetDashboardType";
    public readonly apiTableauDashboardCategory: string ="/tableauuseradmin/GetDashboardCategory";
    public readonly apiTableauRemoveUser: string ="/tableauuseradmin/RemoveDashboard";
    public readonly apiTableauUserDashboard: string ="/tableauuseradmin/GetManageDashboardByUsers";
    public readonly apiTableauGetUserDetails: string ="/tableauuseradmin/GetUserDetailsForDashboard"; 
    public readonly apiInsertSelectedUser: string ="/tableauuseradmin/InsertSelectedUserToDashboard"; 
    public readonly apiTableauRemoveAssignedUser: string ="/tableauuseradmin/RemoveAssignedUser";
    public readonly apiGetTableauUserAccount: string ="/UserProfile/GetTableauUserAccount";   
    public readonly apigetAdvanceShipperFilter: string ="/useradministration/Shipper"; 
    public readonly apigetAdvanceCarrierFilter: string ="/useradministration/Carrier"; 
    public readonly dupontValidation:Array<any> = [74,75,76,77,78,79,80,81,82];   
    public readonly chemoursValidation:Array<any> = [146,147,148,149,150,151,152,153,163];  
    public readonly veoliaValidation:Array<any> = [172,173,174,175,176,177,178,179,189];  
    public readonly cortevaValidation:Array<any> = [191,192,193,194,195,196,197,198,208];  
    public readonly dowValidation:Array<any> = [217,218,219,220,221,222,223,224,234];  
}
