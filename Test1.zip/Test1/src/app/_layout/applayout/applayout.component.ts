import { Component, ElementRef, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap/modal/modal.module';
import { Keepalive } from '@ng-idle/keepalive';
import { EventTargetInterruptSource, Idle } from '@ng-idle/core';
import { AuthenticationService } from 'src/app/_services/authentication.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { MenuList, Menu } from 'src/app/_models/menu';
import { User } from 'src/app/_models/user';
import { MenuService, UserService, HelperService } from 'src/app/_services';
import { HomeService } from 'src/app/_services/home.service';
import { Constants } from 'src/app/_global/constants';
import { ChangePasswordService } from 'src/app/_services/changepassword.service';
import { MessageService } from 'src/app/_services/message.service';
import { SessiontimeoutComponent } from 'src/app/components/login/sessiontimeout/sessiontimeout.component';

@Component({
  selector: 'app-root',
  templateUrl: './applayout.component.html',
  styleUrls: ['./applayout.component.css'],
})
export class ApplayoutComponent implements OnInit {
  title = 'CassPort';
  idleState = 'NOT_STARTED';
  timedOut = false;
  lastPing?: Date = null;
  progressBarPopup: NgbModalRef;
  user: User;
  menuList: Menu[];
  footerVersion: string;
  footerText: Array<any> = [];
  username: string;
  companyType: string;
  messageList: Array<any>;
  messageBadge: number = 0;
  result: any;
  dropdownHeight: string = "";
  helpmenu: Array<any> = [];
  isPasswordExpired: boolean = false;
  passwordExpirationDays: number;
  passwordexpireddays: any;
  isImpersonate:boolean;
  envURL: any;

  constructor(private element: ElementRef, private idle: Idle, private keepalive: Keepalive,
    private ngbModal: NgbModal, private authenticateService: AuthenticationService,
    private menuService: MenuService, private homeService: HomeService,
    private constants: Constants,
    private userService: UserService,
    private changePasswordService: ChangePasswordService,
    private messageService: MessageService,
    private router: Router,
    private helperService: HelperService) {
    idle.setIdle(3600);
    // sets a timeout period of 5 minutes.
    idle.setTimeout(300);
    // sets the interrupts like Keydown, scroll, mouse wheel, mouse down, and etc
    idle.setInterrupts([
      new EventTargetInterruptSource(
        this.element.nativeElement, 'keydown DOMMouseScroll mousewheel mousedown touchstart touchmove scroll')]);

    idle.onIdleEnd.subscribe(() => {
      this.idleState = 'NO_LONGER_IDLE';
    });

    idle.onTimeout.subscribe(() => {
      this.idleState = 'TIMED_OUT';
      this.timedOut = true;
      this.closeProgressForm();
    });

    idle.onIdleStart.subscribe(() => {
      this.idleState = 'IDLE_START';
      this.openProgressForm(1);
    });

    idle.onTimeoutWarning.subscribe((countdown: any) => {
      this.idleState = 'IDLE_TIME_IN_PROGRESS';
      this.progressBarPopup.componentInstance.count = (Math.floor((countdown - 1) / 60) + 1);
      this.progressBarPopup.componentInstance.progressCount = this.reverseNumber(countdown);
      this.progressBarPopup.componentInstance.countMinutes = (Math.floor(countdown / 60));
      this.progressBarPopup.componentInstance.countSeconds = countdown % 60;
    });

    // sets the ping interval to 15 seconds
    keepalive.interval(15);
    this.reset();
  }

  ngOnInit() {
    this.getUserDetails();
    this.getMenus();
    this.footerText = this.constants.footerLink;
    this.helpmenu = this.constants.helpMenu;
    this.envURL = environment.envUrl;
    this.getFooterVersion();
    this.getPasswordExpirationDays();
  }

  getMenus() {
    this.menuService.GetMenus()
      .subscribe((data: MenuList) => {
        if (data) {
          this.menuList = data.navItems;
          this.helperService.log(this.menuList);
        }
      });
  }

  getFooterVersion() {
    this.homeService.GetFooterVersionNo().
      subscribe((data: any) => {
        if (data) {
          this.footerVersion = "CassPort (" + data.versionNo + ")";
        }
      });
  }

  getActiveMessage() {
    this.messageService.GetMessagesForHeader()
      .subscribe((data: any) => {
        if (data) {
          this.messageList = data.Result.filter(m => m.isRead === false);
          this.messageBadge = this.messageList.length;
          if (this.messageBadge == 0) {
            this.dropdownHeight = 'dropdownMinHeight';
          }
          else {
            this.dropdownHeight = 'dropdownMaxHeight';
          }
        }
      });
  }

  updateStatus(item: any): void {
    this.messageService.UpdateMessageStatus(item.messageId, item.sessionId)
      .subscribe((data: any) => {
        if (data) {
          this.result = data.Result;
          this.router.navigate(['/notification/MessageDetail', item.messageId, item.sessionId]);
          this.getActiveMessage();
        }
      });
  }

  closeMenu(){
    this.menuList.forEach(item => {
      item.active = false;
    });
  }

  openSubApplication(value): void {
    this.UnLock();
    if (value) {
     this.closeMenu();
      this.authenticateService.ClearSessionStorageValue();
    }
  }

  getPasswordExpirationDays() {
    this.changePasswordService.getPasswordExpiration()
      .subscribe((data: any) => {
        if (data) {
          this.passwordexpireddays = data.Result;
          if (this.passwordexpireddays.passwordExpirationDays <= 15) {
            this.isPasswordExpired = true;
            this.passwordExpirationDays = this.passwordexpireddays.passwordExpirationDays;
          }
        }
      });
  }
  getUserDetails() {
    this.userService.getUserDetails()
      .subscribe((data: any) => {
        if (data) {
          this.user = data.Result;
          this.username = this.user.firstName + " " + this.user.lastName;
          this.companyType = this.user.companyType;
          this.isImpersonate = this.user.impersonate;          
        }
      });
  }

  reverseNumber(countdown: number) {
    return (300 - (countdown - 1));
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  openProgressForm(count: number) {
    this.progressBarPopup = this.ngbModal.open(SessiontimeoutComponent, {
      backdrop: 'static',
      keyboard: false
    });
    this.progressBarPopup.componentInstance.count = count;
    this.progressBarPopup.result.then((result: any) => {
      if (result === undefined || result == 'logout') {
        this.logout();
      }
      else {
        this.reset();
      }
    });
  }

  logout() {
    this.resetTimeOut();
    this.authenticateService.logout()
      .subscribe((data: any) => {
        window.location.href = environment.SignoutUrl;
      });
  }

  closeProgressForm() {
    this.logout();
    this.progressBarPopup.close();
  }

  resetTimeOut() {
    this.idle.stop();
    this.idle.onIdleStart.unsubscribe();
    this.idle.onTimeoutWarning.unsubscribe();
    this.idle.onIdleEnd.unsubscribe();
    this.idle.onIdleEnd.unsubscribe();
  }

  UnLock(){
    this.authenticateService.GetUnlockUser()
      .subscribe((data: any) => {
        if (data) {
        }
      });
  }

}

