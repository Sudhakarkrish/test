import { Component, OnInit, Input } from '@angular/core';
//import {Constants} from '../../_global/constants';
//import { HomeService } from 'src/app/_services/home.service';

@Component({
  selector: 'cass-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  @Input() footerLink: Array<any> =[];
  @Input() versionNumber: string;
  fullYear:any;
  constructor() { }

  ngOnInit() {
    var hours = new Date();
    this.fullYear = hours.getFullYear();    
  }
}
