import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

declare function Logout() : any;

@Component({
  selector: 'cass-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  @Input() username: any;
  @Input() companyType: any;
  @Input() messageList: Array<any>;
  @Input() messageBadge: number = 0;
  @Input() dropdownHeight: string="";
  @Input() helpmenu: Array<any> =[];
  @Input() isPasswordExpired: boolean = false;
  @Input() passwordExpirationDays: number ;
  @Input() passwordexpireddays:any;
  @Output() updateStatus = new EventEmitter();
  @Output() logoutUser = new EventEmitter();
  currentSelected: {};
  isSupressd: boolean = true;
  modalRef : NgbModalRef;
  navigateFrom = "Menu";
  @Input() isImpersonate: boolean;
  @Input() envURL: any;  
  constructor(private modal:NgbModal,
      private router: Router, private http: HttpClient ) { }


  ngOnInit() {

  }

  NavigatetoDashboard(){
    this.router.navigate(['/Menu'],{ state: { success: this.navigateFrom } });
   }

  getStatusStyle(status) {
    if(status==1){
      return 'messageDanger';
    }
    else if(status ==2){
      return 'messageWarning';
    }
    else if(status == 3){
      return 'messageSuccess';
    }   
  }

  getStatusStyleExport(status) {
    if(status == 1){
      return 'messageSuccess';
    }
    else if(status == 0){
      return 'messageDanger';
    }      
  }

  getPasswordStyle(status){
    if(status <= 5){
      return 'messageDanger';
    }
    else if(status <= 15){
      return 'messageWarning';
    }  
  }

  Navigation(link:any)
  {
    window.open(link, "CarrierGuide", "width=900,height=800,scrollbars=1,resizable=1", true);
  }

  ContactUs(){
    window.open("https://www.cassinfo.com/freight-audit-payment/contact-us", "Contact", "width=1000,height=700,scrollbars=1,resizable=1", true);
  }
  
  
  open(content) {
    this.modalRef = this.modal.open(content, { size: 'sm',backdrop:'static',keyboard:false });
  }

  logout(){
    this.modalRef.close();
    this.logoutUser.emit();
  }

  redirectToMessage():void{
    this.router.navigate(['/notification/MyMessage']);
  }

  updateMessageStatus(messageType: string, value: number): void{
    let messageId =0;
    let sessionId =0;
    if(messageType != 'ExportSession'){
      messageId = value;
    }
    else{
      sessionId =value;
    }
    this.currentSelected = {messageId : messageId, sessionId:sessionId};
    this.updateStatus.emit(this.currentSelected); 
  }

}
