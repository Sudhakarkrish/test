import { NgModule } from '@angular/core';
import { UicommoncomponentsComponent } from './uicommoncomponents.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { MenuComponent } from './menu/menu.component';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    UicommoncomponentsComponent,
    HeaderComponent,
    FooterComponent, 
    MenuComponent     
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    RouterModule,
    NgbModule,
    HttpClientModule
  ],
  exports: [
    UicommoncomponentsComponent,
    HeaderComponent, 
    FooterComponent, 
    MenuComponent
  ]
})
export class UicommoncomponentsModule { }
