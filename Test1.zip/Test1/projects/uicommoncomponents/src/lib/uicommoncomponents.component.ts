import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cass-uicommoncomponents',
  template: `
    <p>
      uicommoncomponents works!
    </p>
  `,
  styles: []
})
export class UicommoncomponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
