import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {Router} from '@angular/router';
import { Menu } from '../models/menu';

declare function doRemittanceWindow() : any;
declare function doPerfMetricsWindow() : any;
declare function doClientManualsWindow() : any;
declare function doProcessWindow() : any;
declare function doRejectWindow() : any;
declare function doBillingGuidesWindow() : any;
declare function doInvoiceRouteWindow(param) : any;

@Component({
  selector: 'cass-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  @Input() menus: Menu[];
  @Input() envURL:any;  
  @Output() openSubApplication = new EventEmitter();
  
  open:boolean = true;
  close:boolean = false;
  isExpanded:boolean = true;
  constructor( private router:Router) { }

  ngOnInit() {    

  }

  openmenu(){
    this.open = false;
    this.close = true;
    this.isExpanded = false;
    this.toggleSubMenu('true');
 }

 closemenu(){
  this.open = true;
  this.close = false;
  this.isExpanded = true;
  this.toggleSubMenu('true');
 }

 NavigationtoSubApp(value:any){
  this.openSubApplication.emit(value);  
 }

 toggleSubMenu(parentMenu: any) {   
   if(parentMenu != 'true') {
    parentMenu.active = !parentMenu.active;
    this.menus.forEach(menu => {
      if (menu.name !== parentMenu.name) {
      menu.active = false;
      }
    });  
  }
  else{
    this.menus.forEach(menu => {
      menu.active = false;
    });  
  }
 } 

 NavigatetoJavaScriptApp(callback: any){
  callback = callback.split(":")[1];
  if(callback == "doRemittanceWindow()")
    doRemittanceWindow();
  else if(callback == "doPerfMetricsWindow()")
    doPerfMetricsWindow();
  else if(callback == "doClientManualsWindow()")
    doClientManualsWindow();
  else if(callback == "doProcessWindow()")
    doProcessWindow();
  else if(callback == "doRejectWindow()")
    doRejectWindow();
  else if(callback == "doBillingGuidesWindow()")
    doBillingGuidesWindow();
  else if(callback == "doInvoiceRouteWindow('')")
    doInvoiceRouteWindow('');
 }

}
