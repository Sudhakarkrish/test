import { BaseModel } from './basemodel';

export class MenuList extends BaseModel{
  Result : Menu[]; 
}

export class MenuItemDetail{
  cassportNavItemId: number;
  parentCassportNavItemId: number;
  linkUrl: string;
  text: string;
  menuGroup: string;
  minLoginLevel: number;
  isEnabled: boolean;
  explicitSortOrder: number;  
  groupName: string;
  menuIcon: string;
  isScriptMenu: boolean;
}

export class Menu{
    name : string;
    menuIcon: string;
    active: boolean = false;
    menuGroup: MenuGroup[];
}

export class MenuGroup{
    groupName: string;
    linkUrl: string;
    menuItems: MenuItemDetail;
} 
