import { BaseModel } from './basemodel';

export class User extends BaseModel{    
    userName: string;
    roleName: string;
    firstName: string;
    lastName: string;
    loginLevel: number;
    companyType:string;
    userAccountId: number;
    privilegeIds:Array<any>;
}
