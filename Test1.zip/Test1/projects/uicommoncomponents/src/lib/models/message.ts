import { BaseModel } from './basemodel';

  export class MyMessages extends BaseModel{
    Result : Message[]; 
    totalCount : number;
  }
  
  export class Message{
    newMessageId: number;
    newMessageName: string;
    priority: string;
    activeImeediately: Boolean;
    activeStartDate?: Date;
    activeEndDate?: Date;
    newMessageType: number;
    newMessageText: string;
    isRead: Boolean;
    priorityOrder: number;
  }
  
  export class ExportSession{
      name : string;
      status: number;
      sessionId: number;
      isRead: Boolean;
  }
  