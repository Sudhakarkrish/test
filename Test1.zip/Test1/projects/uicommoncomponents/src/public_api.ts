/*
 * Public API Surface of uicommoncomponents
 */

export * from './lib/uicommoncomponents.service';
export * from './lib/uicommoncomponents.component';
export * from './lib/uicommoncomponents.module';
